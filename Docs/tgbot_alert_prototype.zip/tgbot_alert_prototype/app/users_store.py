import json
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Dict, List, Set, Optional

USERS_FILE = Path("users.json")


@dataclass
class RegisteredUser:
    telegram_id: int
    organization_id: str
    organization_name: str
    on_shift: bool = False  # на смене или нет


USERS: Dict[int, RegisteredUser] = {}  # user_id -> user


def load_users() -> None:
    global USERS
    USERS.clear()

    if not USERS_FILE.exists():
        return

    with USERS_FILE.open("r", encoding="utf-8") as f:
        raw_list: List[dict] = json.load(f)

    for item in raw_list:
        user = RegisteredUser(
            telegram_id=int(item["telegram_id"]),
            organization_id=item["organization_id"],
            organization_name=item.get("organization_name", ""),
            on_shift=bool(item.get("on_shift", False)),
        )
        USERS[user.telegram_id] = user


def save_users() -> None:
    data = [asdict(u) for u in USERS.values()]
    with USERS_FILE.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def register_user(telegram_id: int, organization_id: str, organization_name: str) -> RegisteredUser:
    user = RegisteredUser(
        telegram_id=telegram_id,
        organization_id=organization_id,
        organization_name=organization_name,
        on_shift=False,
    )
    USERS[telegram_id] = user
    save_users()
    return user


def set_shift(telegram_id: int, on_shift: bool) -> Optional[RegisteredUser]:
    user = USERS.get(telegram_id)
    if not user:
        return None
    user.on_shift = on_shift
    save_users()
    return user


def get_on_shift_users_for_org(organization_id: str) -> Set[int]:
    result: Set[int] = set()
    for u in USERS.values():
        if u.organization_id == organization_id and u.on_shift:
            result.add(u.telegram_id)
    return result

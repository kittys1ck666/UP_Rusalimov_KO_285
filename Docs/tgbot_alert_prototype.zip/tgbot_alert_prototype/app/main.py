import logging

logging.basicConfig(level=logging.INFO)

import asyncio
import uuid
from typing import Dict

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.types import (
    CallbackQuery,
    Message,
    ReplyKeyboardMarkup,
    KeyboardButton,
)
from aiogram.filters import Command

from app.schemas import AlertIn, Alert
from app.config import (
    TELEGRAM_BOT_TOKEN,
    TELEGRAM_CHAT_ID,
    ALLOWED_TELEGRAM_IDS,
    ORGANIZATIONS,
)
from app.telegram_utils import send_alert, format_alert_text
from app.users_store import (
    load_users,
    register_user,
    set_shift,
    get_on_shift_users_for_org,
    USERS,
)

app = FastAPI(title="tgAlert_prototype", version="0.2.0")

# CORS — на будущее, если будет фронт
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Бот и диспетчер (long polling)
bot = Bot(token=TELEGRAM_BOT_TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
dp = Dispatcher()

# Хранилище тревог в памяти
ALERTS: Dict[str, Alert] = {}


def is_authorized(user_id: int) -> bool:
    """
    Пользователь считается авторизованным, если:
    - он есть в USERS (прошёл /register),
    - и, если ALLOWED_TELEGRAM_IDS не пустой, ещё и входит в этот белый список.
    """
    if ALLOWED_TELEGRAM_IDS:
        return (user_id in ALLOWED_TELEGRAM_IDS) and (user_id in USERS)
    return user_id in USERS


# Клавиатура для управления сменой
shift_kb = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="🟢 Выйти на смену"),
            KeyboardButton(text="⚪ Закончить смену"),
        ]
    ],
    resize_keyboard=True,
)


@app.on_event("startup")
async def on_startup():
    # загружаем ранее зарегистрированных пользователей
    load_users()

    if not TELEGRAM_BOT_TOKEN:
        print("[WARN] Telegram token is empty — бот не запустится.")
        return

    loop = asyncio.get_event_loop()
    loop.create_task(start_bot())


async def start_bot():
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    except Exception as e:
        print(f"[ERROR] Bot polling stopped: {e}")


# ────────────────────
#     ХЭНДЛЕРЫ БОТА
# ────────────────────

@dp.message(Command("start"))
async def cmd_start(message: Message):
    """
    Приветственное сообщение.
    Регистрация — через /register КОД_ОРГАНИЗАЦИИ,
    выход/конец смены — через кнопки.
    """
    await message.answer(
        "Добро пожаловать в систему оповещения.\n\n"
        "1️⃣ Сначала зарегистрируйтесь по коду организации:\n"
        "<code>/register ANVIR</code>\n\n"
        "2️⃣ Затем используйте кнопки ниже, чтобы отмечать выход на смену "
        "и её завершение.",
        reply_markup=shift_kb,
    )


@dp.message(Command("register"))
async def cmd_register(message: Message):
    """
    Регистрация пользователя с привязкой к организации по коду.
    Коды организаций задаются в ORGANIZATIONS (config.py).
    """
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        codes = ", ".join(ORGANIZATIONS.keys()) or "нет доступных кодов"
        await message.answer(
            "Для регистрации укажите код организации.\n"
            "Формат: <code>/register КОД</code>\n"
            f"Доступные коды: {codes}",
            reply_markup=shift_kb,
        )
        return

    code = parts[1].strip().upper()
    org = ORGANIZATIONS.get(code)
    if not org:
        await message.answer(
            "Неверный код организации.\n"
            "Проверьте код или обратитесь к администратору.",
            reply_markup=shift_kb,
        )
        return

    user_id = message.from_user.id

    # Если включён белый список — дополнительная защита
    if ALLOWED_TELEGRAM_IDS and user_id not in ALLOWED_TELEGRAM_IDS:
        await message.answer(
            "⛔ У вас нет доступа к этому боту.\n"
            "Обратитесь к администратору безопасности.",
            reply_markup=shift_kb,
        )
        return

    user = register_user(
        telegram_id=user_id,
        organization_id=org["id"],
        organization_name=org["name"],
    )

    await message.answer(
        f"Вы успешно зарегистрированы как сотрудник организации:\n"
        f"<b>{user.organization_name}</b>.\n\n"
        "Теперь отметьте выход на смену кнопкой ниже, "
        "чтобы начать получать тревоги.",
        reply_markup=shift_kb,
    )


@dp.message(F.text == "🟢 Выйти на смену")
async def on_shift_start(message: Message):
    """Охранник заступает на смену."""
    user_id = message.from_user.id

    if not is_authorized(user_id):
        await message.answer(
            "⛔ Вы ещё не зарегистрированы.\n"
            "Сначала используйте: <code>/register КОД_ОРГАНИЗАЦИИ</code>",
            reply_markup=shift_kb,
        )
        return

    user = set_shift(user_id, True)
    if not user:
        await message.answer(
            "Не удалось обновить статус смены. Обратитесь к администратору.",
            reply_markup=shift_kb,
        )
        return

    await message.answer(
        f"🟢 Вы заступили на смену.\n"
        f"Организация: <b>{user.organization_name}</b>.\n"
        "Теперь вы будете получать тревожные уведомления.",
        reply_markup=shift_kb,
    )


@dp.message(F.text == "⚪ Закончить смену")
async def on_shift_end(message: Message):
    """Охранник завершает смену."""
    user_id = message.from_user.id

    if not is_authorized(user_id):
        await message.answer(
            "⛔ Вы ещё не зарегистрированы.\n"
            "Сначала используйте: <code>/register КОД_ОРГАНИЗАЦИИ</code>",
            reply_markup=shift_kb,
        )
        return

    user = set_shift(user_id, False)
    if not user:
        await message.answer(
            "Не удалось обновить статус смены. Обратитесь к администратору.",
            reply_markup=shift_kb,
        )
        return

    await message.answer(
        f"⚪ Вы завершили смену.\n"
        f"Организация: <b>{user.organization_name}</b>.\n"
        "Новые тревоги приходить не будут, пока вы снова не выйдете на смену.",
        reply_markup=shift_kb,
    )


@dp.message(Command("test"))
async def cmd_test(message: Message):
    """Отправка тестового тревожного уведомления в текущий чат."""
    user_id = message.from_user.id
    if not is_authorized(user_id):
        await message.answer(
            "⛔ У вас нет доступа к тестированию. Обратитесь к администратору."
        )
        return

    # Для теста жёстко указываем организацию "anvir"
    payload = AlertIn(
        organization_id="anvir",
        device_id="demo-cam-1",
        timestamp="2025-11-11T18:23:00Z",
        image_url="https://i.pinimg.com/originals/ee/eb/2e/eeeb2e4163162858a9733aade3f8302b.jpg",
        confidence=0.88,
        threat_type="firearm",
        location="Демонстрационная зона",
    )
    alert_id = str(uuid.uuid4())
    alert = Alert(id=alert_id, payload=payload, status="queued")
    ALERTS[alert_id] = alert

    text = format_alert_text(payload.model_dump())
    await send_alert(bot, user_id, text, alert_id, payload.image_url)
    ALERTS[alert_id].status = "sent"
    await message.answer(f"Тестовый алерт отправлен (alert_id={alert_id}).")


@dp.message(Command("history"))
async def cmd_history(message: Message):
    """
    История последних тревог для организации пользователя.
    """
    user_id = message.from_user.id

    if not is_authorized(user_id):
        await message.answer(
            "⛔ У вас нет доступа к просмотру истории. Обратитесь к администратору."
        )
        return

    user = USERS.get(user_id)
    if not user:
        await message.answer(
            "Вы ещё не зарегистрированы в системе.\n"
            "Используйте команду вида:\n"
            "<code>/register КОД_ОРГАНИЗАЦИИ</code>"
        )
        return

    org_id = user.organization_id

    alerts_for_org = [
        a for a in ALERTS.values() if a.payload.organization_id == org_id
    ]

    if not alerts_for_org:
        await message.answer("Для вашей организации тревог пока нет.")
        return

    # последние 10, новые сверху
    last_alerts = list(alerts_for_org)[-10:]
    last_alerts.reverse()

    lines: list[str] = []
    for a in last_alerts:
        lines.append(
            f"<b>ID:</b> <code>{a.id}</code>\n"
            f"<b>Камера:</b> {a.payload.device_id}\n"
            f"<b>Тип:</b> {a.payload.threat_type}\n"
            f"<b>Время:</b> {a.payload.timestamp}\n"
            f"<b>Статус:</b> {a.status}\n"
            f"<b>Локация:</b> {a.payload.location or '-'}\n"
            "— — —"
        )

    text = "🕓 История последних тревог вашей организации:\n\n" + "\n".join(lines)
    await message.answer(text)


@dp.callback_query(F.data.startswith("ack:"))
async def on_ack(query: CallbackQuery):
    """Подтверждение тревоги через кнопку в боте."""
    user_id = query.from_user.id
    if not is_authorized(user_id):
        await query.answer("У вас нет прав для обработки тревоги.", show_alert=True)
        return

    alert_id = query.data.split(":", 1)[1]
    alert = ALERTS.get(alert_id)
    if not alert:
        await query.answer("Событие не найдено.", show_alert=True)
        return

    # уже обработана ранее
    if alert.status in ("acknowledged", "false_positive"):
        await query.answer("Тревога уже была обработана ранее.", show_alert=True)
        return

    alert.status = "acknowledged"

    # убираем кнопки
    try:
        await query.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass

    await query.message.answer(f"✅ Подтверждено оператором (alert_id={alert_id})")
    await query.answer("Принято")


@dp.callback_query(F.data.startswith("false:"))
async def on_false(query: CallbackQuery):
    """Пометка тревоги как ложной через кнопку."""
    user_id = query.from_user.id
    if not is_authorized(user_id):
        await query.answer("У вас нет прав для обработки тревоги.", show_alert=True)
        return

    alert_id = query.data.split(":", 1)[1]
    alert = ALERTS.get(alert_id)
    if not alert:
        await query.answer("Событие не найдено.", show_alert=True)
        return

    # уже обработана ранее
    if alert.status in ("acknowledged", "false_positive"):
        await query.answer("Тревога уже была обработана ранее.", show_alert=True)
        return

    alert.status = "false_positive"

    # убираем кнопки
    try:
        await query.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass

    await query.message.answer(f"⚪ Отмечено как ложное (alert_id={alert_id})")
    await query.answer("Отмечено")


# ────────────────────
#     FASTAPI ЭНДПОИНТЫ
# ────────────────────

@app.post("/api/alerts")
async def create_alert(payload: AlertIn):
    """
    Создание тревоги из внешней системы детекции.

    Уведомления отправляются только тем пользователям,
    которые:
    - принадлежат organization_id,
    - сейчас находятся "на смене".
    """
    alert_id = str(uuid.uuid4())
    alert = Alert(id=alert_id, payload=payload, status="queued")
    ALERTS[alert_id] = alert

    recipients = get_on_shift_users_for_org(payload.organization_id)

    if not recipients:
        ALERTS[alert_id].status = "no_recipients"
        return JSONResponse(
            {
                "status": "no_recipients",
                "alert_id": alert_id,
                "detail": f"Нет сотрудников 'на смене' для organization_id={payload.organization_id}",
            }
        )

    try:
        text = format_alert_text(payload.model_dump())
        for chat_id in recipients:
            await send_alert(bot, chat_id, text, alert_id, payload.image_url)
        ALERTS[alert_id].status = "sent"
    except Exception as e:
        ALERTS[alert_id].status = "failed"
        raise HTTPException(
            status_code=500, detail=f"Не удалось отправить уведомление: {e}"
        )

    return JSONResponse({"status": "queued", "alert_id": alert_id})


@app.post("/api/alerts/{alert_id}/ack")
async def ack_alert(alert_id: str):
    """Подтверждение тревоги по HTTP (альтернатива кнопке в боте)."""
    alert = ALERTS.get(alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.status = "acknowledged"
    return {"status": "acknowledged", "alert_id": alert_id}


@app.get("/api/alerts/{alert_id}")
async def get_alert(alert_id: str):
    alert = ALERTS.get(alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    return alert


@app.get("/health")
async def health():
    return {"ok": True}

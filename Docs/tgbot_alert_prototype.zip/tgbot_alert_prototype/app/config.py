import os
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))

_raw_allowed_ids = os.getenv("ALLOWED_TELEGRAM_IDS", "").strip()
ALLOWED_TELEGRAM_IDS: set[int] = set()
if _raw_allowed_ids:
    for part in _raw_allowed_ids.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            ALLOWED_TELEGRAM_IDS.add(int(part))
        except ValueError:
            print(f"[WARN] Не удалось разобрать Telegram ID '{part}'")

if not TELEGRAM_BOT_TOKEN:
    print("[WARN] TELEGRAM_BOT_TOKEN is not set. Bot won't be able to send messages.")
if not TELEGRAM_CHAT_ID:
    print("[WARN] TELEGRAM_CHAT_ID is not set. Please set a valid chat id for demo.")
if ALLOWED_TELEGRAM_IDS:
    print(f"[INFO] Разрешённых Telegram-пользователей: {len(ALLOWED_TELEGRAM_IDS)}")

# Коды организаций, которыми ты оперируешь
ORGANIZATIONS = {
    "ANVIR": {
        "id": "anvir",
        "name": "ООО «АНВИРТЕХНО»",
    },
    "TC1": {
        "id": "tc1",
        "name": "Торговый центр «Европа»",
    },
    "UNI1": {
        "id": "uni1",
        "name": "Образовательное учреждение",
    },
}

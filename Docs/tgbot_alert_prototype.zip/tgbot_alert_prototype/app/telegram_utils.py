from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram import Bot


def build_alert_keyboard(alert_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Подтвердить тревогу",
                    callback_data=f"ack:{alert_id}",
                ),
                InlineKeyboardButton(
                    text="⚪ Ложная тревога",
                    callback_data=f"false:{alert_id}",
                ),
            ]
        ]
    )


def format_alert_text(data: dict) -> str:
    # data = payload.model_dump()
    return (
        "<b>Обнаружено оружие!</b>\n\n"
        f"🏢 Организация: {data.get('organization_id', '-')}\n"
        f"📷 Камера: {data.get('device_id')}\n"
        f"📍 Локация: {data.get('location') or '-'}\n"
        f"⚠️ Тип угрозы: {data.get('threat_type')}\n"
        f"📊 Уверенность модели: {data.get('confidence'):.2f}\n"
        f"⏱ Время: {data.get('timestamp')}"
    )


async def send_alert(bot: Bot, chat_id: int, text: str, alert_id: str, image_url: str | None):
    kb = build_alert_keyboard(alert_id)
    if image_url:
        await bot.send_photo(chat_id, image_url, caption=text, reply_markup=kb)
    else:
        await bot.send_message(chat_id, text, reply_markup=kb)

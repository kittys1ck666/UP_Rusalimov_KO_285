from pydantic import BaseModel, HttpUrl, Field
from typing import Optional
from uuid import UUID

class AlertIn(BaseModel):
    organization_id: str 
    device_id: str = Field(..., description="Идентификатор камеры/устройства")
    timestamp: str = Field(..., description="ISO-время обнаружения")
    image_url: str = Field(None, description="Ссылка на снимок/кадр")
    confidence: float = Field(..., ge=0, le=1, description="Доверие модели (0..1)")
    threat_type: str = Field(..., description="Тип угрозы, например 'firearm'")
    location: Optional[str] = Field(None, description="Локация/зона")

class Alert(BaseModel):
    id: str
    payload: AlertIn
    status: str = "new"

# tgAlert Prototype

Прототип REST API приложения для отправки уведомлений об угрозах в Telegram. Приложение получает события об обнаружении оружия с камер видеонаблюдения и отправляет оповещения оператору через Telegram бота.

## 🚀 Основные возможности

- **REST API** для приема оповещений об угрозах
- **Telegram интеграция** — отправка сообщений с кнопками подтверждения
- **Управление статусом** — операторы могут отмечать оповещения как подтвержденные или ложные срабатывания
- **Вложение изображений** — поддержка отправки фото с места происшествия
- **In-memory хранилище** для прототипирования

## 📋 Требования

- Python 3.9+
- FastAPI
- aiogram (Telegram Bot API)
- Uvicorn

## ⚙️ Установка

1. Клонируйте репозиторий и перейдите в директорию:

```bash
cd tgbot_alert_prototype
```

2. Установите зависимости:

```bash
pip install -r requirements.txt
```

3. Создайте файл `.env` с учетными данными:

```
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_CHAT_ID=your_chat_id_here
HOST=127.0.0.1
PORT=8000
```

## 🏃 Запуск

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Приложение запустится на `http://localhost:8000`

## 📡 API Endpoints

### Создать оповещение

```
POST /api/alerts
Content-Type: application/json

{
  "device_id": "camera_01",
  "timestamp": "2025-11-11T12:30:45Z",
  "image_url": "https://example.com/image.jpg",
  "confidence": 0.95,
  "threat_type": "firearm",
  "location": "Зона А, Корридор 2"
}
```

**Ответ:**

```json
{
  "status": "queued",
  "alert_id": "550e8400-e29b-41d4-a716-446655440000"
}
```

### Получить статус оповещения

```
GET /api/alerts/{alert_id}
```

### Подтвердить оповещение

```
POST /api/alerts/{alert_id}/ack
```

### Health Check

```
GET /health
```

## 📱 Telegram интеграция

Оппонент получает сообщение с двумя кнопками:

- **🟢 Принять** — отмечает оповещение как подтвержденное
- **⚪ Ложно** — отмечает как ложное срабатывание

## 🗂️ Структура проекта

```
app/
├── main.py              # FastAPI приложение и обработчики
├── config.py            # Конфигурация (переменные окружения)
├── schemas.py           # Pydantic модели данных
├── telegram_utils.py    # Утилиты для работы с Telegram
└── __init__.py
requirements.txt
.env
README.md
```

## 📝 Статусы оповещений

- `queued` — оповещение в очереди
- `sent` — отправлено в Telegram
- `acknowledged` — подтверждено оператором
- `false_positive` — отмечено как ложное срабатывание
- `failed` — ошибка при отправке

## ⚠️ Примечание для продакшена

- Текущая версия использует in-memory хранилище. Для production нужна база данных
- Требуется аутентификация для API endpoints
- Нужна логирование и мониторинг
- Рекомендуется использовать HTTPS

## 📄 Лицензия

MIT
